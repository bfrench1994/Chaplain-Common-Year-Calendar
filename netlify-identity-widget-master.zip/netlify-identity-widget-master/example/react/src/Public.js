import React from 'react';
export default function Public() {
  return <h3>Public</h3>;
}
